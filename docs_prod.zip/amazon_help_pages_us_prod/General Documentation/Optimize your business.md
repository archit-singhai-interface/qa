---
title: Optimize your business
url: https://sellercentral.amazon.com/help/hub/reference/GWU5WMK8UR8XHHC2
section: General Documentation
---

Customer Loyalty Analytics: Segment customers by loyalty, analyze their
purchasing patterns, and implement targeted engagement strategies to boost
your customer lifetime value.

For more information, go to [Customer Loyalty Analytics overview
(PDF)](https://m.media-amazon.com/images/G/01/SGD_Marketing/CLAGuideQ224.pdf)

