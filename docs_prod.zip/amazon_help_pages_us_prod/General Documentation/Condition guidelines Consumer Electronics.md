---
title: Condition guidelines: Consumer Electronics
url: https://sellercentral.amazon.com/help/hub/reference/G8XMHR394Y6MDH2V
section: General Documentation
---

##

In addition to the general [condition guidelines](/gp/help/G200339950), you
may be required to obtain approval to list certain products in the Electronics
category. For more information, see [Categories Requiring
Approval](/gp/help/G200333160).

