---
title: XML reference
url: https://sellercentral.amazon.com/help/hub/reference/G69042
section: General Documentation
---



