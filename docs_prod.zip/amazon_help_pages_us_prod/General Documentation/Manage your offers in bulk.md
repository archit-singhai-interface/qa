---
title: Manage your offers in bulk
url: https://sellercentral.amazon.com/help/hub/reference/G9DZLGS87GVDT94B
section: General Documentation
---

**Individual sellers:** This feature is only available to sellers with a
Professional selling plan. Learn more by visiting [Selling plan
comparison](/gp/help/64491).

You can use inventory files to upload or manage your offers in bulk. Also, you
can view the products listed on Amazon successfully by downloading an
inventory report. For more information on how to use inventory files and
reports effectively, select a page from the left navigation pane.

