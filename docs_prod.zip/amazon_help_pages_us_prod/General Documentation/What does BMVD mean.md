---
title: What does "BMVD" mean?
url: https://sellercentral.amazon.com/help/hub/reference/G200384340
section: General Documentation
---

BMVD is used as an abbreviation for "Books, Music, Video and DVD" products. A
"BMVD Product" means any book, magazine or other publication, sound recording,
video recording, and/or other media product in any format. BMVD Products
include subscriptions to magazines, book clubs, music clubs and similar
arrangements.

