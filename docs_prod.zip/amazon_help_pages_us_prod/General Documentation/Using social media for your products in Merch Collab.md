---
title: Using social media for your products in Merch Collab
url: https://sellercentral.amazon.com/help/hub/reference/GJ5KXBWSM96N8QDE
section: General Documentation
---

Driving awareness and telling your audience you have new branded products on
Amazon is an important part of being successful with Merch Collab. The most
effective way to inform and engage your audience is by using your own social
media channels to excite and engage your followers.

To drive sales and awareness, refer to the tips on creating compelling images
and using the social media listed below:

  * Image guidance for marketing your products
  * YouTube
  * Instagram
  * Twitter
  * Facebook

