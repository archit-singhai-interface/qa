---
title: Product feeds overview
url: https://sellercentral.amazon.com/help/hub/reference/G200986880
section: General Documentation
---

Watch an overview of the process of uploading inventory to Amazon.

**Note:** Tutorials are best viewed in 1600x900 screen resolution.

