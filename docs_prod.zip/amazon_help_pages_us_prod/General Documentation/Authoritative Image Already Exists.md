---
title: Authoritative Image Already Exists
url: https://sellercentral.amazon.com/help/hub/reference/G864APBMA4HCKXGS
section: General Documentation
---

An image will fail to upload if we prefer to use an image that already exists
for this product.

