---
title: Dietary supplements
url: https://sellercentral.amazon.com/help/hub/reference/G201829010
section: General Documentation
---

**Important:** If you supply products for sale on Amazon, you must comply with
all federal, state, and local laws and Amazon policies applicable to those
products and product listings.

Dietary supplements are vitamins, minerals, herbs, or other substances, such
as amino acids or fatty acids eaten to supplement the diet. They often come in
forms like tablets, capsules, softgels, gelcaps, powders, and liquids.

Supplements must be correctly described and labeled, and they must not be
prohibited by Amazon policies. Use the checklist below to be sure your product
can be sold on Amazon.

## Compliance Checklist

Packaging  

  1. Supplements must be sealed in the original manufacturer’s packaging
  2. Supplements must be new and unused
  3. Supplements must clearly display the identifying codes placed on the packaging by the manufacturer or distributor, such as matrix codes, lot numbers, or serial numbers

Labeling  

  1. Supplements must be labeled in English with the following information:  

    1. The name of the dietary supplement
    2. The total quantity or amount of the dietary supplement, such as 100 tablets, 5 mg, 6 oz
    3. A “Supplement Facts” panel
    4. The ingredient list
    5. The name and address of the manufacturer, packer, or distributor
  2. Supplement labels must not contain disease claims or implied disease claims, unless the statement has been approved by the FDA. Disease claims include claims to diagnose, state that the products cure, mitigate, treat, or prevent a disease in humans. The FDA has provided criteria to assist entities in evaluating dietary supplement claims in their [Small Entity Compliance Guide on Structure/Function Claims](https://www.fda.gov/regulatory-information/search-fda-guidance-documents/small-entity-compliance-guide-structurefunction-claims). Disease claims require prior approval by FDA and may only be made by approved drug products.
  3. Supplement labels must not claim that the products have the same effects as controlled substances or prescription drugs, such as names that could be confused with controlled substances or prescriptions drugs, like “Viagrex” or “TestosterX”)
  4. Supplement labels must not claim that the supplements are “FDA approved”
  5. Supplement labels must not use the FDA logo
  6. Supplement labels must not state “tester,” “not for retail sale,” or “not intended for resale”

For more information, visit the U.S. Food and Drug Administration's resources:

[Dietary Supplement Ingredient Dictionary](https://www.fda.gov/food/dietary-
supplements/dietary-supplement-ingredient-
directory?utm_medium=email&utm_source=govdelivery)

[Small Entity Compliance Guide on Structure/Function
Claims](https://www.fda.gov/regulatory-information/search-fda-guidance-
documents/small-entity-compliance-guide-structurefunction-claims)

[Dietary Supplement Labeling
Guide](http://www.fda.gov/Food/GuidanceRegulation/GuidanceDocumentsRegulatoryInformation/DietarySupplements/ucm070519.htm)

[Is It Really 'FDA
Approved?'](https://www.fda.gov/forconsumers/consumerupdates/ucm047470.htm)

Detail page  

  1. Detail pages must include the following information:  

    1. The name of the dietary supplement
    2. The ingredient list, including an image of the ingredient list from the product label
    3. The total quantity or amount of the dietary supplement, such as 100 tablets, 5 mg, 6 oz
    4. A direct image clearly showing the entire product label, including applicable facts panel, ingredients list, certification logos, identity statement, instructions for use, any product warnings. Must also include the product name, and the name and contact information of the brand owner or manufacturer.
  2. Detail pages must not state that the products cure, mitigate, treat, or prevent a disease in humans, unless that statement is approved by the FDA. For examples, go to [Prohibited Product Claims](/gp/help/G202024200).
  3. Detail pages must not include disease names in the keywords
  4. Detail pages must not state that the products have the same effects as controlled substances or prescription drugs. Supplements cannot state that they are alternatives to prescription drugs or that they are just as effective as a prescription drug
  5. Detail pages must not claim that the products produce an effect similar to that of an anabolic steroid, such as "Legal Steroids"
  6. Detail pages must not state that the supplements are “FDA approved”
  7. Images associated with detail pages must not include the FDA logo

Products and ingredients  

  1. Supplements must not be named in an FDA recall or safety alert. For more information, go to [Recalls, Market Withdrawals, & Safety Alerts](https://www.fda.gov/Safety/Recalls/default.htm).
  2. Supplements must not contain ingredients prohibited by the FDA (such as, contaminants or pharmaceutical drugs). For more information, go to [Dietary Supplement Products & Ingredients](https://www.fda.gov/Food/DietarySupplements/ProductsIngredients/default.htm).
  3. Supplements must not be adulterated, such as being unsafe or lacking evidence of safety, or misbranded like having false or misleading information on the label in an FDA warning letter. For more information, go to [FDA Warning Letters](https://www.fda.gov/ICECI/EnforcementActions/WarningLetters/default.htm).
  4. Supplements must be safe for use and must not be a product that the FDA has determined presents an unreasonable risk of injury or illness, such as:
     * Products that contain pure powdered caffeine. For more information, go to [Pure and Highly Concentrated Caffeine](https://www.fda.gov/Food/DietarySupplements/ProductsIngredients/ucm460095.htm).
  5. Supplements must not be named by the Federal Trade Commission (FTC) as making untrue marketing claims. For more information, go to [Federal Trade Commission Press Releases](https://www.ftc.gov/news-events/press-releases).
  6. Supplements must not contain controlled substances, such as:  

    1. Cannabidiol (CBD), a Schedule I Controlled Substance. For more information, go to [Restricted Products: Drugs & Drug Paraphernalia](/gp/help/200164490).
    2. Anything listed in Schedules I, II, III, IV or V of the Controlled Substances Act. For more information, go to [Schedules of Controlled Substances](https://www.deadiversion.usdoj.gov/schedules/).
    3. "List I" chemicals or their derivatives as designated by the Drug Enforcement Administration (DEA). For more information, go to [List I and List II Chemicals](https://www.deadiversion.usdoj.gov/chem_prog/34chems.htm).
  7. Supplements must comply with Amazon policies, including:  

    1. [The Food Safety and Compliance: Dietary Supplement Policy](/help/hub/reference/external/55N3JF2WQS7RVNE)
    2. Supplements that contain ingredients derived from animals that are prohibited under the [Endangered Species Act](https://www.fws.gov/law/endangered-species-act), the [Migratory Bird Act of 1918](https://www.fws.gov/laws/lawsdigest/migtrea.html), the [Wild Bird Conservation Act](https://www.fws.gov/law/wild-bird-conservation-act#:~:text=The%20Wild%20Bird%20Conservation%20Act,not%20beneficial%20to%20the%20species), the [Bald and Golden Eagle Protection Act](https://www.fws.gov/law/bald-and-golden-eagle-protection-act), the [Marine Mammal Protection Act](https://www.fws.gov/law/marine-mammal-protection-act), the [Lacey Act](https://www.aphis.usda.gov/aphis/ourfocus/planthealth/import-information/lacey-act/lacey-act), or the [Convention on International Trade in Endangered Species](https://www.fws.gov/cites#:~:text=The%20Convention%20on%20International%20Trade,their%20survival%20in%20the%20wild), including, but not limited to, sharks, whales, dolphins, or porpoises, are prohibited from sale.
    3. Supplements that contain more than 12% hydrogen peroxide are prohibited from sale
    4. Patches that are marketed as dietary supplements or detox products are prohibited from sale

## Additional Useful Resources

  * The Federal Trade Commission`s Health Products Compliance Guidance accessible at <https://www.ftc.gov/system/files/ftc_gov/pdf/Health-Products-Compliance-Guidance.pdf>
  * LegitScript has a searchable database that may help when determining if a supplement includes a prohibited ingredient. For more information, go to <https://www.legitscript.com/>.
  * The U.S. Anti-Doping Agency has a list of high-risk supplements that may help when determining if a supplement includes a prohibited ingredient. For more information, go to <https://www.usada.org/substances/supplement-411/>.

## Related Amazon Help Pages

  * [Restricted Products: Animals & Animal Products](/gp/help/200164370)
  * [Restricted Products: Cosmetics](/gp/help/200164470)
  * [Restricted Products: Food & Beverage](/gp/help/200164550)
  * [Restricted Products: Drugs & Drug Paraphernalia](/gp/help/200164490)
  * [Restricted Products: Medical Devices & Accessories](/gp/help/200164650)
  * [Restricted Products: Prohibited Product Claims ](/gp/help/G202024200)

## Known Prohibited Products

Amazon specifically prohibits the following Supplement products. These
products are prohibited because they do not meet the checklist requirements.
This list does not include all Supplement products prohibited by Amazon.

Effective December 6, 2021, for Sexual Enhancement and Weight Loss Dietary
Supplements, the product cannot be sold in single or double pill packs. Single
and double pill pack offerings will be restricted from sale on Amazon.

  * 1 Day Diet
  * 1 Minute Miracle products
  * 1,4 AD Bold
  * 1,4 AD Bold 200
  * 100% Healthy Food For Men
  * 17a PheraFLEX3-AD
  * 2 Day Diet
  * 2 Day Diet Slim Advance
  * 2 Own the Knight Silver 4000
  * 21 Double Slim
  * 24 Hours Diet
  * 24 Hours Diet
  * 24 Ince
  * 2x Powerful Slimming
  * 365 Skinny High Intensity
  * 3 Day Diet
  * 3 Days Fit
  * 3 Hard Knights
  * 3 KO
  * 3-AD
  * '3rd Degree' by Xtreme Elite X
  * 3x Slimming Power
  * 3xGood Life & Perfect Shape
  * 4-AD
  * 4EVERON
  * 5x Imelda Perfect Slimming
  * 60-OXO Xtreme
  * 6-OXO
  * 69 MODE Blue 69
  * 7 Day Herbal Slim
  * 7 Days Diet
  * 7 Diet
  * 7 Diet Day/Night Formula
  * 72 Hours
  * 8 Factor Diet
  * 999 Fitness Essence
  * AB Slim manufactured by AB Care
  * ABC Dophilus Powder
  * Abdomen Smoothing Capsules
  * Absonutrix patches
  * Acacia Rigidula
  * Acai Berry Coffee
  * Acai Berry Soft Gel ABC
  * Acceleration
  * Accretropin
  * ACE Appetite Control Energy Dietary Supplement Pills
  * Achieving Zero
  * Achieving Zero Advanced
  * Achieving Zero evolve
  * Achieving Zero Max
  * AcraSX
  * Activ Otc
  * Activ Slim slimming capsules
  * Actra-Rx
  * Actra-Sx
  * Adam Free
  * Adam’s Secret
  * Adipotrim XT - fluoxetine
  * Adralin
  * Adrenal extract
  * Adrenalean
  * Adrenaline XR
  * A-Drol
  * AD-Rx
  * Advanced Slim 5
  * African Superman tablets
  * AFX
  * AH-89-XtremeArimaDex
  * Aisiyuan V26 Slimming Granules
  * Akttive Capsules
  * Akttive High Performance Fat Burner Gold capsules
  * Alfia Weight Loss Capsules
  * All products containing 30% or more synephrine
  * All products containing picamilon
  * All Vitamist Sprays
  * Allerclear
  * Alpha Male
  * Alpha Male Plus
  * Alpha T
  * Alteril Fast Acting Softgels
  * American Bangster
  * AmidrenApple Slim
  * Amour for him
  * AMP citrate (4-amino-2-methylpentane citrate)
  * AMPD Gold Bee Pollen
  * Anabolic Countdown 321zero
  * Anabolicum Vister
  * Anadraulic Pump
  * Anadrol
  * Anadroll
  * Anarchy Covalex
  * Anavar
  * Anavone
  * Andarine
  * Andriol Testocaps
  * Androstenedione
  * Androstenetrione
  * Anorex
  * AN-Rx
  * Ansomone
  * Antabolic
  * APEXXX
  * APL
  * Apple's Quick Impact Weight Loss
  * ArimaDex
  * Arize Male Sexual Enhancer
  * ARO Black Series BURN
  * Arom-X
  * Arom-X UTT
  * Arom-XL
  * Arousin
  * Arth-Q
  * Artri Ajo King
  * Artri King
  * Asellacrin
  * Asia black
  * Asihuri Plus Forte
  * A-Slim 100%
  * Aspire Lite
  * Aspire One
  * Aspire36
  * Asset Bee Pollen
  * Asset Bold
  * Asset Extreme
  * Asset Extreme Plus
  * Australia Kangaroo Essence
  * Avaphinal
  * Avena Sativa
  * Averbol
  * AV-Rx
  * Aziffa
  * Bak Foong Pills
  * Bali Mojo
  * Baolong
  * Baschi
  * Basha Nut
  * Basha Nut 100% Fruit Soft Gel
  * Be Inspired
  * Beamonstar Extenze
  * Beamonstar Top Gun Enhancer
  * Beastdrol
  * Beta-nicotinamide mononucleotide (NMN, β-NMN)
  * Beautiful Slim Body
  * Bee Slim
  * Bee Thin
  * beFIT Total Garcinia Cambogia
  * Behavior Balance DMG Liquid
  * Bella Vi Amp'd Up
  * Bella Vi Insane Amp'd Up
  * Best Line Suplemento Alimenticio Capsules
  * Best Whips
  * Beyond Balance products
  * Bigger Longer
  * BioEmagrecim - fenproporex, furosemide, fluoxetine
  * BioEmagrecim, sample 1 - fenproporex
  * BioEmagrecim, sample 2 - fluoxetine, furosemide
  * Biogra
  * BioGuard
  * Biolean
  * Biorhythm SSIN Juice
  * Bio-Tropin
  * Black 3k 3000
  * Black Ant
  * Black Ant King
  * Black beauty
  * Black Cats
  * Black Gold X Advanced
  * Black ice
  * Black King Kong
  * Black knight
  * Black Label X
  * Black Mamba Hyperrush
  * Black Spider 25
  * Black Stallion 9000
  * Black Widow
  * Black widow
  * Black_3k
  * BlackStone Labs manufactured supplements
  * B-Lipo manufactured by Bethel Nutritional
  * Blood Rush Pump
  * Blue Diamond
  * Blue Fantasy capsules
  * Blue Panther Extreme 75k
  * Blue slim
  * Blue Steel
  * Blue Stinger
  * BMPEA
  * Bnew Beauty and Body
  * Bo Ying Compound manufactured by Eu Yan SangFlawless Beauty and Skin manufactured products
  * Body Bentonite Unique Healing Powder
  * Body Creator
  * Body Shaping
  * Body Shape Weight Loss System
  * Body Slimming
  * Boladrol
  * Boost Ultra
  * BOSC Enterprises Epi-Tren
  * Boss Number #Six
  * Botanical Slimming
  * Botanical Slimming (Red)
  * Botanical Slimming Soft Gel
  * Botanical Weight Loss
  * B-Perfect
  * Brahma Male Enhancement
  * BrainStrong products
  * Brazil Perfect
  * Brazil Potent Slimming Coffee
  * Brazilian Slimming Coffee
  * Breathe easy
  * Bromodrol
  * BSAID
  * BtRim Max
  * Bull’s Genital
  * BulletProof
  * Bumetanide
  * Burn 7
  * Burn Fat Now by Advance Herbal Research
  * Burn max
  * Burro en Primavera 60000
  * Casanova
  * Caution
  * CBD (cannabidiol)
  * Celerite Slimming Capsules
  * Celerite Slimming Tea
  * Cetilistat
  * CF-Rx
  * Chainsaw Extreme
  * Charge Extreme Energy Booster
  * Cheque Drops
  * China Brush
  * China white
  * China white
  * Chlorodehydromethyl testosterone
  * Cholestene
  * CholeSterin manufactured by Atrium
  * Chong Cao Zhang Bian Bao
  * Chorionic
  * Cialis
  * CigRX - anatabine
  * Cissus Drol
  * Citrus Fit Gold
  * Clalis
  * Clear Shot 3x Concentrate
  * Clenadrol-X
  * Clomed
  * Clomed-PCT
  * Clyamax
  * CoB9 Dietary Supplement
  * Cockstar
  * Code Red
  * Cold FX
  * Collagen Slim
  * Competitive Edge Labs X-tren
  * Component TH with Tylan 20 Doses
  * CONTROL
  * Core Zap
  * Corvalol products
  * Cougar Secret Honey VIP
  * Crane Beauty Green Algae Body Slimming Combination
  * Crane Beauty Green Algae Complex Tablets
  * Crane Beauty Green Algae Compound Tablets
  * Crane Beauty Green Algae Perfect Match
  * Creafuse Power (Grape & Fruit Punch)
  * Creatine Freak by PharmaFreak
  * CreOcell
  * Crescormon
  * CTD Labs manufactured supplements
  * Cyanostane
  * Cycle Support
  * D Stunner
  * Daidaihua Jiao Nang
  * Danabol
  * Dball or D-ball
  * DBOL
  * D-BOL
  * D-Drol
  * Deca Durabolin
  * Deca Nor 50
  * Deca-Bolin
  * Decavol
  * Deccabolin
  * Deep Relief Ibuprofen & Levomenthol Gel
  * Deer antler velter
  * Dekka150
  * Depth Charge
  * Dermatotropin
  * Desmthylsibutramine
  * Destroy the Enemy
  * Detonate by Gaspari Nutrition
  * Detox Intestinal Drawing Formula
  * Dexaprine
  * DEXAPRINE XR
  * Diablos ECA Fire Caps
  * Di-Acid Stim manufactured by Atrium
  * Dianabol
  * Dianadrol
  * Dick's Hard Up
  * Didesmthylsibutramine
  * Dienedronel
  * Diet burn
  * Diet Master
  * Dinitrophenol or DNP
  * DMAA (1,3-dimethylamylamine)
  * DMBA (1,3-dimethylamylamine)
  * DMHA (1,5-dimethylhexylamine)
  * Doctor's Best "Red Yeast Rice"
  * Dpol
  * D-pol
  * Dr. Reade Slim Sense
  * Dragon Power
  * Dream Body Slimming Capsule
  * Driven Sports manufactured supplements
  * Drotaverine
  * D-Stianozol
  * Du Zhong Jin Gu Wan
  * Dual Action Grow Tabs
  * Durabolin
  * Durazest For Men
  * Duro Extend
  * Duro Extend Capsules for Men
  * Dyma-Burn
  * Dyma-Burn Xtreme
  * Dymetadrine Xtreme
  * Dymethazine
  * Dymethazine
  * Dymethazine/Reversitol Combo Pack
  * Dynamizm
  * Dynapep Energy Microshot
  * E.T Tren-250
  * ECA Fatburner
  * EDGE Amplified Weight Release
  * Eight Factor Diet
  * Ejaculoid XXTREME
  * El Torito Black Bull Power 500 mg
  * El Torito Extreme 500 mg
  * El Torito Plus 1000 mg
  * Elimite
  * Elimulating Weight & Toxin Keeping Beauty products
  * Emperor's Tea Pill (Tian Huang Bu Xin Wan)
  * Endotropin
  * Endowmax
  * Energel
  * Energy Max
  * Enerup Premium
  * Engystol
  * Enhance
  * Enhance9
  * Enhanced Vegetal Vigra capsules
  * Enhancement
  * ENVY BP
  * Eph 100
  * Eph 25
  * Ephedra
  * Ephedra sinica
  * Epio-Plex
  * Epistane
  * Epi-Tren
  * Epivol
  * E-pol Inslinsified
  * ErectMax
  * Eradicate
  * Erex
  * Erexin
  * Erexa
  * Erextra
  * Erexxx
  * Erousa
  * Esbelin siloutte Herbal Blend with L-Carnitine
  * E-Shred
  * Esmeralda softgels
  * ESTRO Xtreme
  * Etumax VIP
  * Ever Slim
  * Everlax
  * Exhilarate
  * Exn
  * Extenze Tablets
  * Extenzen
  * Extenzone
  * Extra Slim Plus Acai Berry
  * Extreme Diamond 3000
  * Extreme Fat Burner
  * Extreme power plus
  * Extreme Stack Fat Burner
  * Extrim Plus
  * Extrim Plus 24 Hour Reburn
  * Eyeful
  * Ezerex
  * Fastin
  * Fasting Diet
  * FASTIN-XR
  * Fat Smack XR
  * Fataway Ultimate Stack
  * Fatloss Slimming
  * Fenfluramine
  * Feng Shi Ling
  * Fenproporex
  * Filix Mas
  * Fina
  * Finabolic 50
  * Finadex
  * Finaflex 550-XD
  * Finaflex Epi V
  * Finaflex Ignite 2
  * Finaflex Limited Edition
  * Finaflex Methyl Ice
  * Finaflex NO Ignite
  * Finaflex Pro Xanthine
  * Finaflex Ripped
  * Finally On Demand
  * Finaplix-H
  * Fire starter
  * Fitropin
  * Flashover
  * Flexile-Plus manufactured by Aspen
  * Fluoxetine
  * For Store Only
  * Forever Beautiful Bee Pollen
  * Forever Beautiful Infinity
  * Forged Burner
  * Forged Extreme Mass
  * Forged Lean Mass
  * Forta For Men products
  * Francis Herb Farm "All Seasons Detox Kit"
  * Francis Herb Farm "Bulklax V"
  * Fresh Lemon Slimming
  * Fruit Plant Lossing Fat Capsule
  * Fruta Bio
  * Fruta Planta
  * Fuel Up High Octabe capsules
  * Fuel Up Plus capsules
  * FuFang
  * Full Throttle On Demand
  * Fung Shing Pai Tian-Ma Wan
  * Furious X 1350
  * Furosemide
  * Fury Extreme
  * FX3000
  * Gat Fornatab
  * Genabol
  * Genesis Ultra Slim Gold
  * Genotropin
  * Geranamine
  * GERMANY NIUBIAN
  * Ginseng Kianpi Pill
  * Ginseng Power-X
  * Ginseng Power 5000
  * Ginseng She Lian Wan
  * Global Dragon Linzi Dong Mai Dan
  * Global Wellness manufactured products
  * Glucobiotic Supreme manufactured by Nutri-Pak
  * GMP
  * GNC "Herbal Plus" Echninacea
  * GNC "Herbal Plus" Gingko Biloba
  * GNC "Herbal Plus" Ginseng
  * GNC "Herbal Plus" Saw Palmetto
  * GNC "Herbal Plus" St. John's Wort
  * Go On Red
  * Gold Lion
  * Gold Max For Men
  * Gold Max For Women
  * Gold Max Maximum Strength
  * Gold Viagra
  * Gold Viagra capsules
  * Gold Viagra tablets (packaged as "Kangaroo Sexually Invigorating Essence"
  * Golden Night
  * GoldReallas
  * Goodliness Fat-Reducing capsules
  * Goya Bittermelon
  * Gra-MaxX Gold
  * Green Algae
  * Green e
  * Green Lean Body Capsule Super Slim
  * Green stinger
  * Grow Tabs
  * Grow Tabs TR
  * Growth Hormone
  * GTF-Rx
  * Halo For Her
  * Halobolin, manufactured by MyoPharma
  * Halodrol
  * Halodrol Liquidgels
  * Halotestin
  * Halovar, manufactured by Purus Labs
  * Happy Passengers
  * Hard AF
  * Hard Drive
  * Hard Ten Days
  * Hard Wang
  * HCG (Human Chorionic Gonadotropin)
  * H-Drol
  * Health Slimming Coffee
  * Heliotropic supplements
  * Helmi’s Honey VIP
  * Hemo Rage Black
  * Hepatico Extract (Shu Gan Wan)
  * Herb Viagra Male Sexual Stimulant
  * Herbal Health Backplus 500mg
  * Herbal Health JI Special Cream
  * Herbal Health Jointcare
  * Herbal Health RU Special Cream
  * Herbal Health V+
  * Herbal Health XIANG Special Cream
  * Herbal Health YI Special Cream
  * HERBAL VIAGRA
  * Herbal Vigor Quick Fix
  * Herbal Vivid supplements
  * Herbal Xenicol - cetilistat
  * Herbalife Original Green
  * Herberex
  * Hero
  * Higenamine
  * HG4 Up
  * HGH (Human Growth Hormone)
  * High Octane
  * Hi-Tech manufactured supplements
  * HMG Xtreme
  * Hokkaido Slimming
  * Hongkong Tianli Biological 'Power' tablets
  * HoneyGizer
  * Honeymoon Exclusive for Men & Women
  * Hot Detox
  * Hot Rod
  * HS Joy of Love
  * Humatrope
  * Hybrid Preamp
  * Hydravax
  * Hydroxa-7
  * Hydroxadrine
  * Hydroxy ripped
  * Hydroxy Stac
  * Hydroxycut with ephedra
  * Hydroxystim
  * Hydroylean
  * Hydroymax
  * Hypercuts
  * Hyperdrol X2
  * HyperleanFX7
  * Hypnos
  * IBU-Relief 12 Cream
  * Idebenone
  * iForce Nutrition manufactured products
  * IGF-1 (Insulin-Like Growth Factor-1)
  * IGF-2
  * Igtropin
  * Imelda Fat Reducer
  * Imelda Perfect Slim
  * Imperial Extreme 2000
  * Imperial Gold 2000
  * Imperial Platnium 2000
  * Imperla Elita Vitaccino
  * IM-Rx
  * Increlex
  * Indian God Lotion
  * iNDiGO
  * Infinity
  * Innerget Everlasting Strength
  * Innerget Instant Erection
  * Innerget Prolonged Performance
  * iNSANE Bee Pollen
  * Instant V-XL
  * Intellux
  * Iowa Select Herbs supplements
  * Iplex
  * IronMagLabs manufactured supplements
  * Isxperia select
  * Ja Dera
  * Ja Dera 100% Natural
  * Jack’D Sexual Enhancement
  * Jack Rabbit
  * Jack3D
  * Jacked up
  * Jaguar Power
  * Jamaican Stone
  * Japan Hokkaido Cangye
  * Japan Lingzhi
  * Japan Rapid Weight Loss Diet Pills Blue - phenolphthalein
  * Japan Rapid Weight Loss Diet Pills Green - phenolphthalein
  * Japan Rapid Weight Loss Diet Pills Yellow - phenolphthalein
  * Jetfire
  * Jetfuel Superburn
  * JETFUEL SUPERBURN by GAT
  * JetFuel T-300 by GAT
  * Jianbu Hugian Wan
  * Jianfeijindan Activity Girl
  * Jiao Shou Shen
  * Jiedu Hugian Wan Tablets
  * Jimpness Beauty Fat Loss Capsules
  * Jin Long Snake Bones Rheumatic
  * JINQIANGBUDOR Red Dragon
  * Jintropin
  * JM Fat Reducer
  * Joint-Soft
  * Joyful Slim - desmthylsibutramine
  * Juiced
  * KaBaNa L-Carnitine 360 Slimming Coffee
  * Kaboom Action Strips
  * Kaizen ephedrine hcl
  * Kangaroo Intense Alpha 3000
  * Kebigutaijiaonang
  * Kilo Sports TrenadrolLiquidrone UTT
  * King of Romance
  * Kingdom Honey Royal Honey VIP
  * Kopi Jantan Traditional Natural Tradisional Natural Herbs Coffee
  * Korvalol products
  * Krazy Night
  * Kwik burn
  * KwikHard
  * Lami Capsules
  * Larry's Tranquility
  * Launch
  * Lazy Larry Brownies
  * Lazy Larry Cakes
  * L-Carnitine Sob Strengthening Version Slimming Miracle Capsule
  * Lean Body Extreme
  * Lean Efx
  * Lecheek Nutrition manufactured supplements
  * Leisure 18 Slimming Coffee
  * Leopard Secret Miracle Honey
  * Levitra
  * Li Da Daidaihua Plus
  * Li Long Mei Guo Mo Bang
  * Libidinal
  * Libido Edge Capsules
  * Libido Sexual Enhancer
  * Libidus
  * LibieXtreme
  * Libigirl
  * Libigrow
  * LibiMax
  * Libimax X Liquid
  * Libiplus
  * Libipower Plus
  * Lida
  * Lida DaiDaihuaLidiy
  * Life Support
  * Lightning 10.0+ Reduces Weight
  * Lightning Rod
  * Liji Shou
  * Lily Dry
  * Lingzhi Cleansed Slim Tea
  * Lipo-6 Black
  * Lipo-6 Black Hers
  * Lipo-6 Black Hers Ultra Concentrate
  * Lipo-6 Black Ultra Concentrate
  * Lipodrene HARDCORE
  * Lipodrene XTREME
  * Lipopastilla + Gold Max
  * LipoSear
  * Lipotherm
  * Lipozol
  * Lishou
  * Lishou Slimming Coffee
  * Lite Fit USA
  * Liu Bian Li
  * Live Clinical
  * Livtone
  * Liviro3
  * Longue Jambe Frères (Brother Long Legs) tablets
  * Lose Weight Coffee
  * Love Fuel
  * Love Fuel 2
  * Lovers Tea For Men
  * LOVher
  * L-Showm Weight Loss Pills
  * Luvena Prebiotic Daily Therapeutic Wash
  * Luvena Prebiotic Enhanced Personal Lubricant
  * Luvena Prebiotic Feminine Wipes
  * Luvena Prebiotic Vaginal Moisturizer & Lubricant
  * LV Shou Reduces Fat
  * LX1
  * Lycium Barbarum L.
  * Lymphomyosot
  * Lypolysis
  * M1, 4AD
  * Ma Huang
  * Ma huang ephedra
  * Madol
  * Madol
  * Magic for Men
  * Magic Male Enhancer
  * MAGIC PENIS
  * Magic Power Coffee
  * Magic Power Coffee
  * Magic Slim
  * Magic Slim Tea
  * Magic Slim Weight Reduction Capsule
  * Magna Drol
  * MagnaRX
  * Magnum Plus
  * Magnum XXL
  * Mahuang Herbal Ephedra
  * Mahuang RP
  * Majestic Lovezone tablets
  * Male Enhancer
  * Male Silkworm
  * Male V Herbs
  * Mamba Is Hero
  * Man King
  * Man Up Now
  * Manners Energy Boost
  * Mao Slimming Capsules
  * Mas Xtreme Capsules
  * Mass Destruction
  * Mass Tabs
  * MASS Xtreme
  * Massdrol
  * MassiveGrowth
  * Mastavol
  * Master Zone 1500
  * Masteron
  * MataboGold
  * Max Hard
  * Max Male Drive
  * Maxadrine
  * MaxHIMize
  * Maxi Gold capsules
  * Maxidus
  * Maxiloss
  * MaximizeIntense
  * Maximum Horny Goat Weed (all other non-tainted supplements containing horny goat weed are permitted)
  * Maximum Powerful
  * Maxman products
  * MaxOut FX by MaxOut Body
  * Maxrize
  * Maxtremezen
  * Maxyte
  * Mayhem by Chaotic Labz
  * MDIT
  * M-Drol
  * Me36
  * Mecasermin
  * Mechano Growth Factor
  * Medcare Golden Royal Honey
  * Mega Slim
  * MegaJex
  * Megaton 2080
  * Meili
  * Meizi Evolution
  * Meizitang
  * Meizitang Citrus
  * Meizitang Strong Version Botanical Slimming
  * Melanotan - II
  * Merida
  * Mero Macho
  * Mesomorph
  * Metabadrine
  * Metabolic Accelerator by MetaPro 360
  * Metabolic Advantage
  * Metabolife
  * Metabolife EZ Tabs
  * Metab-O-Lite
  * Metabosafe
  * Metaboslim
  * Metaboslim
  * Metabothin
  * Metandienone
  * Methadrol
  * Methandienone
  * MethAnstance
  * Methastadrol
  * Methasterone
  * Methyl Drive 2.0
  * Methyl-1-Testosterone
  * Methyldrene
  * Methyldrostanolone
  * MethylHex 4,2
  * Methylstenbolone
  * Methylsynephrine
  * Mezo
  * Miaozi MeiMiaoQianZiJiaoNang
  * Miaozi Slim Capsules
  * Mince Belle
  * Ming's Chinese Capsule
  * Miotolan
  * Mira Health manufactured products
  * Miracle Diet 30
  * Miracle Mineral Supplement (MMS)
  * Miraculous Evil Root
  * Miss Slim
  * Mitactin Scabies Treatment
  * Mitotropin
  * Mix Fruit Slimming
  * MMA-3 Xtreme
  * MMC Maxman V Capsules, Maxman IX Capsules and Maxman XI Tablets
  * MMC Sex Men capsules
  * Mojo
  * Mojo Risen
  * Monster Caps
  * Monster Excyte
  * Moska Energy for Adults
  * Motivate
  * Moze Lady products by Mezo
  * MSS Maximum Sexual Stimulant
  * Muscle marinade
  * Muscle Marinade (MM) - Fresh Fruit, Cherry Limeade, Marinade Grape Juice, and Purus Punch
  * Muscle Spike
  * Musli Power
  * MV5 Days
  * MV7 Days
  * MX-LS7
  * My Man His Enhancer
  * Myagen
  * Myoripped
  * N2 Amp
  * Nai Chang Ming Yan Pills (Ming Yan Pills)
  * Napalm
  * Nasty Mass
  * Nasutra
  * Natadrol dietary supplements by LG sciences
  * Natural Balance Cobra
  * Natural Body Solution
  * Natural Max Slimming
  * Natural Max Slimming Capsule
  * Natural Model
  * Natural Passion
  * Natural Vigor Maximum
  * Naturalë Super Plus
  * Natural-Power
  * NaturalUp
  * Natureal capsules
  * NatuRECT
  * Nature's Science
  * Natur-Leaf
  * Neophase
  * Neophase Natural Sex Enhancer
  * Neuralgo-Rheum
  * NeuRemedy products
  * NeuroCore
  * New Extenze
  * New XZen Platinmun
  * New You Herbal Appetite Suppressant
  * NexGen supplements and topicals
  * NG-Rx
  * Night Bullet
  * Night Man
  * Nine Slim dietary supplements
  * Ninja-X
  * Nite Rider
  * Nite Rider Maximum
  * Nitric Blast
  * Niu Mo Wang 'Bull Monster' tablets
  * Niubian
  * Nopal Blood Sugar
  * Norditropin
  * North America Dami Ana
  * North West Wolf capsules
  * Nostrilla
  * Novadex-XT
  * Novedex XT
  * NovoSculpt
  * Noxipro
  * Nutra Coastal Trena
  * Nutracoastal Trena
  * Nutrex Vitrix
  * Nutri Drops Grapefruit Diet
  * NutriBiotic Grapefruit Seed Extract
  * Nutropin
  * NVIE Edge Pro
  * NX-Rx
  * OcuComp manufactured by Atrium
  * Ocu-Comp manufactured by Nutri-Pak
  * Off Cycle II Hardcore
  * OMG
  * OMG45
  * Omnitrope
  * ON Cycle II Hardcore
  * One Weight Loss Pill
  * Opal by Nuway Distributors
  * Opti-Fast
  * OrgaZEN Gold 5800
  * Original Metabolife
  * Original White Dragon
  * OR-Rx
  * Ortiga
  * Ortiga Mas Ajo Rey
  * Ortiga Mas Ajo Rey Extra Forte
  * OstaMax
  * OstaMuscle
  * Ostarine
  * OstaRX
  * Over drive
  * Oxodrol Pro
  * Oxy Elite Pro
  * Oxy-Charge
  * OxyECA
  * OxyElite Pro Super Thermo capsules
  * p57 Hoodia
  * Pai You Guo
  * Pandora
  * Paradise Suplemento Natural Ultra Plus capsules
  * Paranil
  * Passion Coffee
  * P-Boost
  * PC3x
  * PCA-Rx
  * Pe min kan wan
  * Pearl White Slimming Capsules
  * PEB One manufactured by Renutryent
  * PEB Two manufactured by Renutryent
  * Perfect Body Solutions
  * Perfect Combination Balishou Capsule
  * Perfect Slim
  * Perfect Slim 5x
  * Perfect Slim Up
  * Permethrin Cream
  * Phenadrine
  * PhenExtreme by NutraCell Labs
  * Phenibut
  * Phenolphthalein
  * Phenphedrine
  * Phentraburn SlimmingPhyto Shape - rimonabant
  * Phentramin D
  * Phenyldrene Xtreme
  * Phenytoin
  * Phera-Mass
  * Pheravol-V
  * Phreak
  * Phuk
  * Picamilon
  * Pigmento
  * Pil Raja Urat Asli
  * Pineapple Fat Reducing Slimming Capsule
  * Pink Pussycat
  * Placenta Lucchini
  * Plant Vigra
  * Play Hard For Men
  * Pleo Homeopathic products
  * Plexus Slim Accelerator 3 Day Trial Pack
  * Plexus Slim Accelerator Capsules
  * PN-Rx
  * Poseidon Platinum
  * Potion 9
  * Power 1
  * Power Source Maxxx
  * Powerful Slim
  * Powermania
  * Power-X
  * P-Plex
  * Premier Platinum 5000
  * PremierZen
  * Premium OrgaZen 7000
  * PrePost
  * Primilut N
  * PrimeZen Black 6000
  * Primobolan
  * Pro ArthMax
  * Pro Plus Xtreme
  * Pro Solution Gel and Pills
  * Pro Stanivar
  * Pro V Xtend
  * Proactin_Syrup
  * Prolatis
  * Prolifta Capsules
  * Promatrix DHEA 25
  * Propell Platinum
  * Propranolol
  * ProSlim Plus
  * Protropin
  * Proviron
  * PR-XT Advanced
  * Pure Caffeine Powder
  * Purple Tiger
  * PWR
  * Quake 10.0
  * Que She - fenfluramine; propranolol; sibutramine; ephedrine
  * Quickslim-30
  * R1881
  * Race Caps Supreme
  * Rage
  * Rainbow Rocket
  * Rapha Diet
  * RAPHA Vitamin B1
  * Rapid Action Energize
  * Rapid Release
  * Razor8 Blast Powder
  * Real Deal
  * Real Deal ECA-Stack
  * Real Skill
  * Recombinant
  * Red devils
  * Red Hot Sex
  * Red Magic
  * Red Mammoth
  * Red Spartan 3000
  * Red Spider 5ml
  * Red Stinger Black Label
  * REDDIES
  * Redline Black Diamond
  * Redline Black on Blue V2
  * Redline Ultra Hardcore
  * Redline Xtreme Energy Drink
  * Reduce WeihgtWeight
  * Refresh Green
  * Regen Arouse
  * Regen Erect
  * Regenerect
  * RegeneSlim
  * Renuvetrol
  * Reparil
  * Revalor-H
  * Revalor-IS
  * REVALOR-XS IMPLANT 100DS SO
  * Revamp
  * Revenge
  * Reversitol
  * Revivexxx
  * Rezolution
  * RezzRX
  * Rhino products for male enhancement
  * Rimonabant
  * Ripped force
  * Ripped Juice
  * Ripped Stack
  * Ripped Tabs TR
  * Riptek V2
  * Rise Up
  * Rize 2 The Occasion
  * Robust
  * Rock Hard
  * Rock Hard Extreme
  * Rock Hard Weekend
  * Rock It Man
  * Rock Steady 72 Hours
  * Rockhard
  * Rose 4 Her
  * Royal Honey
  * Royal Slimming Formula
  * RSe7en
  * RV2
  * RV3
  * RV4
  * RV5
  * Rx_erect
  * S Lion Juice 1
  * S.W.A.G.G.E.R Extreme
  * Saizen
  * Salute
  * Samurai-X
  * San Xiao Ping Tang Jin Qi Jiao Nang
  * Sana Plus
  * Sangter
  * Sanovera Starter capsules
  * SanPharma products
  * Santé FX Neo
  * Santé FX Neo
  * Santé FX V+
  * Santé FX V+
  * Santen eye drops
  * Santi Scalper
  * Sci-Fit
  * S-Drol
  * Secret Miracle Honey
  * Seirogan Toi A
  * Semenax
  * Serostim
  * Seven Slim
  * Sex Drive Capsules
  * Sex Enhancer
  * Sexamax
  * Sex-Love Secret Code capsules
  * Sexo_Loco
  * SexRX
  * Sextra
  * Sexual Surge
  * Sexy Monkey
  * Shangai Regular
  * Shangai Regular, also marketed as Shangai Chaojimengnan
  * Shangai Ultra
  * Shangai Ultra X
  * Sheng Jing Pian
  * Sheng Yuan Fang
  * Shengjingpian
  * Shi Hu Ye Guang Wan (Ye Guang Wan)
  * Shogun-X
  * Shorts on the beach by Lucy's Weight Loss System
  * Shoufsy Activity Girl
  * Shree Baidyanath brand
  * Shwasa Sanjeevani
  * Sibutramine
  * Sit and Slim II
  * Six Spirit Pills (Liu Shen Wan)
  * Size Matters
  * Skinny 22
  * Slender Slim 11
  * Slender-Mist Sprays
  * Slim 3 in 1
  * Slim 3 in 1 Extra Slim Formula
  * Slim 3 in 1 Extra Slim Waist Formula
  * Slim 3 in 1 M18 Royal Diet
  * Slim 3 in 1 Slim Formula
  * Slim Burn
  * Slim Easy
  * Slim Expert
  * Slim Expert
  * Slim Express (ผอมขั้นเทพ)
  * Slim Express 360
  * Slim Express 4 in 1
  * Slim Fast
  * Slim Forte Slimming Capsules
  * Slim Forte Slimming Coffee
  * Slim Fortune
  * Slim Fortune
  * Slim Gram
  * Slim Max
  * Slim Perfect Arm
  * Slim Perfect Legs
  * Slim Quick Result 3 in 1
  * Slim Tech
  * Slim Trim U
  * Slim Up
  * Slim Vie
  * Slim Waist Formula
  * Slim Waistline
  * Slim Xtreme
  * Slim Xtreme Herbal Slimming Capsule
  * Slim-30
  * Slimbionic
  * SlimDemand Capsules
  * Slimdia Revolution
  * SlimEasy Herbs Capsules
  * SlimExtra Herbal Capsules
  * Slimfast
  * Slimina weightloss capsules
  * Sliminate
  * Sliming Diet Berry Plus
  * Slim-K manufactured by Bethel Nutritional
  * Slimming Beauty
  * Slimming Diet
  * Slimming Diet by Pretty White
  * Slimming Formula
  * Slimquick Green Coffee Bean Softgel
  * Slyn Both
  * Slyn Both Green capsules
  * Smoking Cessation Aid
  * Solcoseryl
  * Solo Slim
  * Solo Slim Extra Strength
  * Soma
  * Somabolin
  * Somatomedin
  * Somatotrophin
  * Somatotropin
  * Somatrem
  * Somatroph HC
  * Somatropin
  * Somotrim
  * Sonar manufactured products
  * S-organic Cocoa+L-carnitine
  * Source Naturals Male Response
  * South America Maca (all other non-tainted supplements containing maca are permitted)
  * Sparta X
  * Spascupreel
  * Spawn
  * SPCARET Princess Diet
  * Spectrazyme - chloramphenicol
  * Speed V2
  * Spirodene
  * Spirodex
  * Sport Burner
  * Sport X Ephedrine
  * S-shape slim capsules
  * Sta Max Plus
  * Stamina-Rx
  * Staminil
  * Star Majestic
  * Starcaps - bumetanide
  * Star-SX Gold
  * STB Summit of the Thin Body S Woman Degreasing Burning Pill
  * STEAM
  * Steel Libido
  * Stenbolone
  * Sterodrol
  * Steroids
  * Stiff Days
  * Stiff Nights
  * Stiff One Hard 169
  * Stiff Rocks products
  * Stim Force
  * Stimerex es
  * Stimerex-ES
  * Stimuloid II
  * Straight Drol
  * Straight Phlexed
  * Straight Up
  * Stree Overlord
  * Strombafort, Winstrol
  * Strong Horses capsules
  * Strong Testis
  * Strong_Man_Bao
  * Strong-SX
  * Stron-SX capsules
  * Stud Capsules
  * Sudibil-Xr
  * Sulami
  * Super Arthgold
  * Super Bull 6000
  * Super Cal-Pro Powder
  * Super Caps
  * Super Dragon 6000
  * Super Ephedra Extreme
  * Super Extreme Accelerator
  * Super Fat Burner
  * Super Fat Burning
  * Super Fat Burning Bomb
  * Super Hard
  * Super Herbs
  * Super Lean 1000
  * Super Panther 77k
  * Super Power
  * Super Shangai
  * Super Slimming
  * Super Tiger-X
  * Super Tren
  * Super-DMZ Rx 3.0
  * Superdrine
  * Superdrine RX-10
  * Superdrol
  * Super-Flex manufactured by Atrium
  * Superior
  * Superslim
  * SuppressNT
  * Surge XMP
  * SUS-500
  * Sustamed, Sustanon
  * Sustenol 250
  * Susto-Test Depot
  * Svelte 30 Capsules
  * Swagger
  * Synedrex
  * Synovex Choice implants
  * Synovex Plus implants
  * Syntrion productsTraumeel
  * Tacktol
  * Tan Bee Pollen
  * Tanning pills containing canthaxanthin
  * Tantra Jelly Herbal Jelly for Him
  * Target "Up & Up" Gingko Biloba
  * Target "Up & Up" St. John's Wort
  * Target "Up & Up" Valerian Root
  * Tawon Liar
  * Tenfold
  * Tengda
  * Testosterone Cream for Men
  * Testosterone Cream for Women
  * Testra-Flex
  * Tev-Tropin
  * THE BEST Enhancement Supplement
  * The Clear
  * The Natural Alternative by Thin and Slim Naturally
  * The Pink Bikini by Lucy's Weight Loss System
  * The Razor's Edge
  * The Rock
  * Thermbuterol
  * Thermo speed
  * Thermo trim
  * Thermoburn
  * Thermofuse
  * ThermoFX by The People's Chemist
  * Thermogen II
  * Thermogenic Fat Burner by The Store
  * Thermogum
  * Thermojetics Original Green
  * Thermolean
  * Thermra Epimedyumlu Bitkisel Karismli Macun
  * Thinogenics
  * Thumbs Up 7
  * Thyriod Gland by Life Choice Ltd.
  * Thyroid
  * Thyroid extract
  * Tianeptine
  * Tian Ma Toutong Wan
  * Tianji True Slim
  * Tibet Babao
  * Tiger King
  * Tip-Top Shape supplements
  * Titanium 18k
  * TNT Thermanite
  * Tomato Slimming
  * Tongqiao Biyan Pian
  * Tonic Life BP - phenolphthalein
  * Top Man 3
  * Topviril
  * Toxin Discharge Tea
  * Train
  * Tren
  * Tren-250
  * Trena
  * Trenabol
  * TrenadroI-X
  * Trenadrol
  * Trenavar
  * Trenavar
  * Trenbolone
  * TREN-Xtreme
  * Tri-Methyl X
  * Tri-Methyl Xtreme
  * Trim-Fast Slimming Softgel
  * Triple Extenzen
  * Triple MiracleZen Platinum
  * Triple PowerZEN Gold
  * Triple Slim
  * Triple SupremeZen
  * Triple Wicked Platinum 
  * T-Roid
  * Trojans Horse Man Power
  * tru Weight & Energy + truFIX
  * True Man
  * True Man Sexual Energy
  * TruTrim or Tru-Trim weight loss products
  * TT-40-Xtreme
  * Tummy Tuck Max
  * TUPMAX
  * Turanabol
  * Turbo charge
  * Turinabol
  * Turnivol
  * Ubervita products
  * Udep
  * Ultimate
  * Ultimate Antioxidant
  * Ultimate Boost
  * Ultimate Formula Capsules
  * Ultimate Herbal Slimcap capsules by Fit Firm and Fabulous
  * Ultimate orange
  * Ultra Mass Stack
  * Ultra Pure Yohimbe
  * Ultra SX Capsules
  * Ultra ZX
  * Ultra-AV
  * Ultracuts
  * Ultradrol
  * Uprizing 2.0
  * USA Gold Ant capsules
  * USA Viagra
  * USP Labs manufactured supplements
  * V Max
  * V26 Slimming Coffee products
  * V8 Energy
  * Valtropin
  * Vanish containing BMPEA by Pro Supps
  * VasoprophinRX
  * Vaxitrol
  * Velocity XT
  * Vengeance by UG Pharma
  * Venom hyperdrive
  * Venom Hyperdrive 3.0
  * Verect
  * VERSA-1 - aegelineloss
  * Via Xtreme Ultimate
  * ViaFem
  * Viagra
  * Viagra 007
  * Vialipro
  * Viaplus Gold
  * Viapro
  * ViaXtreme
  * Vicerex
  * Vierect
  * Vigor 800
  * Vigor Tea Sachets
  * Vigor-25
  * Vigour 300
  * Vigorous Man
  * Vigra
  * VIM25
  * Vimax
  * Vine Essence
  * Virilis Pro
  * Virility Max
  * Viril-Ity Power (VIP) Tabs
  * Virility VPRX
  * Virmax DS
  * Vitaccino coffee
  * Vital Honey
  * Vital Sex
  * Vitalikor Fast Acting
  * VitaMineral Earth
  * VitaMineral Green
  * Vitapril
  * VNS-9 Xtreme
  * Volcano Male
  * VolumePills
  * VPRX Oil
  * Vswiss
  * Vy & Tea
  * W.A.G. Sex with a Grudge
  * W.-W
  * Waist Strength Formula
  * Walgreens "Finest Nutrition" Echinacea
  * Walgreens "Finest Nutrition" Garlic
  * Walgreens "Finest Nutrition" Gingko Biloba
  * Walgreens "Finest Nutrition" Ginseng
  * Walgreens "Finest Nutrition" St. John's Wort
  * Walmart "Spring Valley" Echinacea
  * Walmart "Spring Valley" Garlic
  * Walmart "Spring Valley" Gingko Biloba
  * Walmart "Spring Valley" Ginseng
  * Walmart "Spring Valley" Saw Palmetto
  * Walmart "Spring Valley" St. John's Wort
  * Warrior Force "Warrior Core Foundation" and "TruGanic"
  * Warrior Force "Warrior Endurance"
  * Warrior Force "Warrior Greens" Vegan Caps
  * Weekend King
  * Weekend Prince
  * Weekend Warrior
  * Whacked out
  * Whatzup
  * White Panther
  * Wild Sexx
  * Wonderful Honey
  * Wood-E
  * WOW
  * Wyked
  * X Rated Honey
  * Xcel
  * Xcel Advanced
  * Xcellerator weight loss products
  * Xenaclen
  * Xenadrine rfa 1
  * XenaleanPro
  * Xerophagy
  * XForMan Plus
  * X-Hero
  * Xiadafil VIP Tabs
  * Xiatrex
  * XM3
  * Xplozion
  * X-Rock
  * Xsvelten
  * Xtra Innings
  * Xtremexcite
  * X-Tren
  * X-TRN
  * XXX Platinum Woodie
  * Xytamax
  * Xytomax
  * XZone Gold
  * Y-4ever
  * Yanhee Slim
  * Yellow bullet
  * Yellow cross
  * Yellow Devils
  * Yellow haze
  * Yellow jacket
  * Yellow power
  * Yellow Scorpion
  * Yellow scorpion
  * Yellow subs
  * Yellow swarm
  * Yilishen
  * Ying Da Wang
  * Ying Dao Di capsules
  * Yin-Yang Essence Men Power
  * Yohimbe Erection Lotion
  * Yong Gang
  * Youth_Addict
  * Yunnan Baiyao
  * Zan-X Extra Relaxation
  * Zeel
  * Zencore Plus
  * Zenerect
  * Zenerx
  * Zeri Xtreme Capsules
  * Zero Fat
  * Zero Xtreme
  * Zhen de Shou
  * Zhen Gong Fu
  * Zhen Gongfu
  * Zhong Hua Niu Bian
  * Zhonghua Niubian
  * Zi Xiu Tang Bee Pollen Capsules (also known as "ZXT Slim Bee Pollen")
  * Ziapro
  * Zilex
  * Zimaxx
  * Zing Plus
  * ZlimXter
  * Zolpeadem
  * Zomacton
  * Zoom-Zooma-Zoom
  * Zorbtive
  * Zotrex
  * ZR dietary capsules
  * ZXT Gold
  * ZXT Gold Infinity
  * Zyogin
  * Zyrexin
  * Zytenz

Last Updated: April 18, 2023

