---
title: Propping
url: https://sellercentral.amazon.com/help/hub/reference/G5SD576VXDFLCR32
section: General Documentation
---

Additional elements that are not part of the product being sold must not be
added to main images. Wallet contents such as cards or photographs must not be
included, and jewelry must not be shown attached to other objects.  
  
Allowed | Not Allowed  
---|---  
![](https://m.media-amazon.com/images/G/01/image_requirements/without_props1.jpg) |  ![](https://m.media-amazon.com/images/G/01/image_requirements/propping1.png) ![](https://m.media-amazon.com/images/G/01/image_requirements/propping2.png) ![](https://m.media-amazon.com/images/G/01/image_requirements/propping3.jpg) ![](https://m.media-amazon.com/images/G/01/image_requirements/propping4.png)

