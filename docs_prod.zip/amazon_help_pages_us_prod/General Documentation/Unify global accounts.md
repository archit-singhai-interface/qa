---
title: Unify global accounts
url: https://sellercentral.amazon.com/help/hub/reference/GJZJNMG4UX3DXSGV
section: General Documentation
---

  1. Go to your Global Account page

  2. Here you will see your Global Account. In order to unify additional accounts into a single global account click on **Add accounts**. You will be taken to a new page to add your credentials.

  3. Add the username and password for the account you wish to add.

  4. Once you log into your second account, you will be redirected to the Global Account page and will see both accounts.

  5. Select the accounts you wish to unify by clicking the boxes next to each of the accounts.

  6. Click **Unify**.

  7. Your accounts will be unified into a new Global Account.

