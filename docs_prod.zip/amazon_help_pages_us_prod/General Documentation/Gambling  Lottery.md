---
title: Gambling & Lottery
url: https://sellercentral.amazon.com/help/hub/reference/G200685250
section: General Documentation
---

**Important:** If you supply products for sale on Amazon, you must comply with
all federal, state, and local laws and Amazon policies applicable to those
products and product listings.

## Examples of Permitted Products

  * Non-functional slot machines created solely for display or as toys

## Examples of Prohibited Products

  * Lottery tickets
  * Coin-operated slot machines
  * Slot machines that can be converted to use coins or currency

## Additional Useful Information

  * [Lotteries information](http://www.gpo.gov/fdsys/pkg/USCODE-2009-title18/html/USCODE-2009-title18-partI-chap61.htm)

