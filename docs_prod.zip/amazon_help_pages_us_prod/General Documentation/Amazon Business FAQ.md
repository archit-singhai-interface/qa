---
title: Amazon Business FAQ
url: https://sellercentral.amazon.com/help/hub/reference/G201740290
section: General Documentation
---



