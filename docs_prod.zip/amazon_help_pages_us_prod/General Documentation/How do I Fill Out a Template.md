---
title: How do I Fill Out a Template?
url: https://sellercentral.amazon.com/help/hub/reference/G201467230
section: General Documentation
---

Inventory templates provide a way for you to upload many listings at one time.
An Inventory File Template is a Microsoft Excel spreadsheet that contains
multiple data columns for describing your products. Use Inventory File
Templates to upload your listings to Amazon. Most Inventory File Templates are
designed for a specific product category. Additional templates can be used to
create or update listings in all categories.

