---
title: Image with Identical ASIN and Variant Submitted
url: https://sellercentral.amazon.com/help/hub/reference/GXP59A6ZVJUFJTFN
section: General Documentation
---

An image will fail to upload if another newer image was uploaded for the ASIN
and variant while your image was still in process of being uploaded to the
site.

A newer image takes precedence over older images.

