# Seller Fulfilled Prime

Section: Seller Flex and Alternative Fulfillment
Original URL: https://sellercentral.amazon.com/help/hub/reference/G201812230

Seller Fulfilled Prime allows you to list your products as Prime-eligible and
handle the fulfillment yourself. As an enrolled seller, you will have Prime
branding displayed on your Prime items that you ship to buyers with same-day,
one-day, two-day, and standard shipping.

To learn more about the program, go to [Seller Fulfilled Prime program
policy](/gp/help/G201812300).

If you’re interested in participating in the program, see [Seller Fulfilled
Prime trial and program enrollment](/gp/help/GEK38DWGHERUDUT6).

